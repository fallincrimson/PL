package com.example.slide.myapplication.network;

/**
 * * Written by @JoeFachrizal 02/10/2019.
 **/
public class ConfigUrl {
    public static final String BASE_URL = "https://plfirebaseproject-c49ea.firebaseio.com/";
    public static final String DATA_BUKU = "dataBuku";
}
