package com.example.slide.myapplication.activity.user.subinformation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.slide.myapplication.R;

public class WisataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wisata);
    }
}
