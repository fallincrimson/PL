package com.example.slide.myapplication.model;

public class DataTemp {
    public static String pathBuku = "dataBuku";
    public static String namaBuku = "";
    public static String noPanggil = "";
    public static String pengarang = "";
    public static String penerbit = "";
    public static String deskripsi = "";
    public static String subjek = "";
    public static String kontenDigital = "";
    public static String eksemplar = "";
}
